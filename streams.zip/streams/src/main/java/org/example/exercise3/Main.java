package org.example.exercise3;

public class Main {
    public static void main(String[] args) {
        Product.filterMethod();

    }
}
